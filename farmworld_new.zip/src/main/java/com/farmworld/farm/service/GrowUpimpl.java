package com.farmworld.farm.service;

import java.util.List;

import com.farmworld.all.domain.Criteria;
import com.farmworld.farm.domain.GrowUpVO;

public class GrowUpimpl implements GrowUp {

	@Override
	public GrowUpVO get(Integer k) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void add(GrowUpVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modify(GrowUpVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Integer k) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<GrowUpVO> growAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<GrowUpVO> searchGrow(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotal(Criteria cri) {
		// TODO Auto-generated method stub
		return 0;
	}

}
