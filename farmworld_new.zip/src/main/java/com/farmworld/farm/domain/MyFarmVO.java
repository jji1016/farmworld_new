package com.farmworld.farm.domain;

import lombok.Data;

@Data
public class MyFarmVO {
	private int farm_num;
	private String farm_name;
	private String farm_intro;
	private int user_num;
	private int image_folder_num;
	private int myfarm_view;
}
