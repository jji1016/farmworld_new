package com.farmworld.all.domain;

import lombok.Data;

@Data
public class ImageVO {
	private int image_folder_num;
	private String image1;
	private String image2;
	private String image3;
}
