package com.farmworld.all.service;

import com.farmworld.all.domain.ImageVO;

public class ImageServiceImpl implements ImageService {

	@Override
	public ImageVO get(Integer k) {
		return null;
	}

	@Override
	public void add(ImageVO vo) {
		
	}

	@Override
	public void modify(ImageVO vo) {
		
	}

	@Override
	public void delete(Integer k) {
		
	}


}
